import argparse
import os

import torch
from transformers import EarlyStoppingCallback, T5Config, TrainingArguments

from models import DASH
from tokenizer import LightCodeTokenizer
from utils.callbacks import IntervalCallback, ModelStateCallback, NegativeResamplingCallback
from utils.collator import DASHCollator
from utils.common import ensure_directory, set_seed
from utils.data import DASHDataset
from utils.trainer import CustomTrainer


def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["Office", "Grocery", "Beauty", "Yelp"], default="Office")
    parser.add_argument("--data_path", default="./data")
    parser.add_argument("--tokenizer_path", default="./config/tokenizer")
    parser.add_argument("--config_path", default="./config/models/t5_config.json")
    parser.add_argument("--output_dir", default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max_history_length", type=int, default=20)
    parser.add_argument("--index_suffix", default=".index.rq-kmeans.json")
    parser.add_argument("--train_sample_count", type=int, default=-1)
    parser.add_argument("--validation_sample_count", type=int, default=-1)
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=4)
    parser.add_argument("--learning_rate", type=float, default=5e-4)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--warmup_ratio", type=float, default=0.01)
    parser.add_argument("--logging_steps", type=int, default=10)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--validation_interval", type=int, default=2)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--validation_beams", type=int, default=20)
    parser.add_argument("--validation_batch_size", type=int, default=None)
    parser.add_argument("--fp16", action="store_true")
    parser.add_argument("--bf16", action="store_true")
    parser.add_argument("--resume_from_checkpoint", default=None)
    DASH.add_model_args(parser)
    return parser


def main():
    args = build_parser().parse_args()
    set_seed(args.seed)
    if args.output_dir is None:
        args.output_dir = os.path.join("ckpt", f"{args.dataset}_DASH")
    ensure_directory(args.output_dir)
    config = T5Config.from_json_file(args.config_path)
    config.architectures = ["DASH"]
    tokenizer = LightCodeTokenizer.from_pretrained(
        os.path.join(args.tokenizer_path, args.dataset), model_max_length=512
    )
    config.vocab_size = len(tokenizer)
    if int(os.environ.get("RANK", "0")) == 0:
        tokenizer.save_pretrained(args.output_dir)
        config.save_pretrained(args.output_dir)
    train_dataset = DASHDataset(
        args, tokenizer, "train", sample_num=args.train_sample_count
    )
    validation_dataset = DASHDataset(
        args, tokenizer, "valid", sample_num=args.validation_sample_count
    )
    model = DASH(config, args)
    model.resize_token_embeddings(len(tokenizer))
    trainer = CustomTrainer(
        model=model,
        train_dataset=train_dataset,
        eval_dataset=validation_dataset,
        args=TrainingArguments(
            seed=args.seed,
            output_dir=args.output_dir,
            per_device_train_batch_size=args.batch_size,
            per_device_eval_batch_size=args.batch_size,
            gradient_accumulation_steps=args.gradient_accumulation_steps,
            num_train_epochs=args.epochs,
            learning_rate=args.learning_rate,
            weight_decay=args.weight_decay,
            warmup_ratio=args.warmup_ratio,
            lr_scheduler_type="cosine",
            logging_steps=args.logging_steps,
            eval_strategy="epoch",
            save_strategy="epoch",
            save_total_limit=5,
            load_best_model_at_end=True,
            metric_for_best_model=f"hit@{args.validation_beams}",
            greater_is_better=True,
            remove_unused_columns=False,
            dataloader_num_workers=args.workers,
            dataloader_persistent_workers=False,
            label_names=["labels"],
            fp16=args.fp16,
            bf16=args.bf16,
            report_to="none",
        ),
        processing_class=tokenizer,
        data_collator=DASHCollator(tokenizer),
        callbacks=[
            EarlyStoppingCallback(early_stopping_patience=args.patience),
            NegativeResamplingCallback(train_dataset, validation_dataset, args.seed),
            ModelStateCallback(),
            IntervalCallback(args.validation_interval),
        ],
        generation_eval_num_beams=args.validation_beams,
        generation_eval_batch_size=args.validation_batch_size,
    )
    model.config.use_cache = False
    trainer.train(resume_from_checkpoint=args.resume_from_checkpoint)
    trainer.save_state()
    trainer.save_model(args.output_dir)


if __name__ == "__main__":
    main()
