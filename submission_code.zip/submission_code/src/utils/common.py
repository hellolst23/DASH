import json
import os
import random

import numpy as np
import torch


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True, warn_only=True)


def ensure_directory(path):
    os.makedirs(path, exist_ok=True)


def constrained_tokens(trie):
    def allowed(batch_id, sentence):
        return trie.get(sentence.tolist())

    return allowed


def save_json(value, path):
    ensure_directory(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2)
