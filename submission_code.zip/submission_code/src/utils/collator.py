import torch


class DASHCollator:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = 0

    def __call__(self, batch):
        inputs = self.tokenizer(
            [example["input_ids"] for example in batch],
            return_tensors="pt",
            padding="longest",
            max_length=self.tokenizer.model_max_length,
            truncation=True,
            return_attention_mask=True,
            add_special_tokens=True,
        )
        labels = self.tokenizer(
            [example["labels"] for example in batch],
            return_tensors="pt",
            padding="longest",
            max_length=self.tokenizer.model_max_length,
            truncation=True,
            return_attention_mask=True,
            add_special_tokens=True,
        )["input_ids"]
        labels[labels == self.tokenizer.pad_token_id] = -100
        inputs["labels"] = labels
        negative_ids = torch.stack([example["negative_ids"] for example in batch])
        batch_size, negative_count = negative_ids.shape[:2]
        inputs["labels_with_negs"] = torch.cat(
            [labels.unsqueeze(1), negative_ids], dim=1
        ).view(batch_size * (negative_count + 1), -1)
        inputs["negative_shared_lengths"] = torch.stack(
            [example["shared_lengths"] for example in batch]
        )
        inputs["negative_divergence_positions"] = torch.stack(
            [example["divergence_positions"] for example in batch]
        )
        return inputs


class EvaluationCollator:
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = 0

    def __call__(self, batch):
        inputs = self.tokenizer(
            [example["input_ids"] for example in batch],
            return_tensors="pt",
            padding="longest",
            max_length=self.tokenizer.model_max_length,
            truncation=True,
            return_attention_mask=True,
            add_special_tokens=True,
        )
        return inputs, [example["labels"] for example in batch]
