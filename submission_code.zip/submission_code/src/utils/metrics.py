import math


def ranking_metrics(predictions, targets, cutoffs):
    totals = {f"hit@{cutoff}": 0.0 for cutoff in cutoffs}
    totals.update({f"ndcg@{cutoff}": 0.0 for cutoff in cutoffs})
    for ranked_items, target in zip(predictions, targets):
        for cutoff in cutoffs:
            selected = ranked_items[:cutoff]
            if target in selected:
                rank = selected.index(target)
                totals[f"hit@{cutoff}"] += 1.0
                totals[f"ndcg@{cutoff}"] += 1.0 / math.log2(rank + 2)
    count = max(len(targets), 1)
    return {name: value / count for name, value in totals.items()}
