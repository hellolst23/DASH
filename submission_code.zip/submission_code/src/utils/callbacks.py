import torch
from transformers import TrainerCallback


class ModelStateCallback(TrainerCallback):
    def on_epoch_begin(self, args, state, control, model=None, **kwargs):
        if model is not None:
            model.set_train_epoch(state.epoch)
        return control


class IntervalCallback(TrainerCallback):
    def __init__(self, interval):
        self.interval = max(1, int(interval))

    def on_epoch_end(self, args, state, control, **kwargs):
        epoch = int(round(state.epoch or 0))
        selected = epoch > 0 and epoch % self.interval == 0
        final = state.epoch is not None and state.epoch >= state.num_train_epochs
        if not (selected or final):
            control.should_evaluate = False
            control.should_save = False
        return control


class NegativeResamplingCallback(TrainerCallback):
    def __init__(self, train_dataset, validation_dataset, seed):
        self.train_dataset = train_dataset
        self.validation_dataset = validation_dataset
        self.seed = seed

    def on_epoch_begin(self, args, state, control, **kwargs):
        epoch = int(state.epoch or 0)
        rank = int(getattr(args, "process_index", 0))
        train_generator = torch.Generator(device="cpu").manual_seed(self.seed + epoch + rank)
        validation_generator = torch.Generator(device="cpu").manual_seed(
            self.seed + epoch + rank + 2025
        )
        self.train_dataset.resample_negatives(generator=train_generator)
        self.validation_dataset.resample_negatives(generator=validation_generator)
        return control
