import json
import os

import numpy as np
import torch
from torch.utils.data import Dataset


class SequenceDataset(Dataset):
    def __init__(self, args, mode, sample_num=-1):
        self.dataset = args.dataset
        self.data_path = os.path.join(args.data_path, self.dataset)
        self.max_history_length = args.max_history_length
        self.index_suffix = args.index_suffix
        self.mode = mode
        self.sample_num = sample_num
        self._load()
        self._remap()
        self.examples = self._build_examples()
        self._all_items = None

    def _load(self):
        with open(os.path.join(self.data_path, f"{self.dataset}.inter.json"), encoding="utf-8") as handle:
            self.interactions = json.load(handle)
        with open(os.path.join(self.data_path, f"{self.dataset}{self.index_suffix}"), encoding="utf-8") as handle:
            self.indices = json.load(handle)

    def _remap(self):
        self.remapped = {
            sequence_id: ["".join(self.indices[str(item)]) for item in items]
            for sequence_id, items in self.interactions.items()
        }

    def _history(self, items):
        if self.max_history_length > 0:
            items = items[-self.max_history_length:]
        return "".join(items)

    def _build_examples(self):
        examples = []
        for items in self.remapped.values():
            if self.mode == "train":
                observed = items[:-2]
                for position in range(1, len(observed)):
                    examples.append({"input_ids": self._history(observed[:position]), "labels": observed[position]})
            elif self.mode == "valid":
                examples.append({"input_ids": self._history(items[:-2]), "labels": items[-2]})
            elif self.mode == "test":
                examples.append({"input_ids": self._history(items[:-1]), "labels": items[-1]})
            else:
                raise ValueError(f"Unsupported split: {self.mode}")
        if self.sample_num > 0:
            chosen = np.random.choice(len(examples), self.sample_num, replace=False)
            examples = [examples[index] for index in chosen]
        return examples

    def get_all_items(self):
        if self._all_items is None:
            self._all_items = ["".join(code) for code in self.indices.values()]
        return self._all_items

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, index):
        return self.examples[index]


class DASHDataset(SequenceDataset):
    def __init__(self, args, tokenizer, mode, sample_num=-1):
        super().__init__(args, mode, sample_num)
        self.sampling = "dash"
        self.negative_count = args.negative_count
        self.item_texts = np.array(self.get_all_items(), dtype=object)
        self.item_token_ids = torch.tensor(
            [tokenizer.encode(item) for item in self.item_texts], dtype=torch.long
        )
        self.item_token_tuples = [tuple(row.tolist()) for row in self.item_token_ids]
        self.positive_token_ids = torch.tensor(
            [tokenizer.encode(example["labels"]) for example in self.examples], dtype=torch.long
        )
        self.item_token_length = self.item_token_ids.shape[1]
        self.max_code_prefix_length = max(0, self.item_token_length - 2)
        self.min_shared_prefix = max(0, args.min_shared_prefix)
        requested_maximum = args.max_shared_prefix
        self.max_shared_prefix = (
            self.max_code_prefix_length
            if requested_maximum <= 0
            else min(requested_maximum, self.max_code_prefix_length)
        )
        if self.max_shared_prefix > 0:
            self.min_shared_prefix = min(self.min_shared_prefix, self.max_shared_prefix)
        else:
            self.min_shared_prefix = 0
        self.shared_negative_count = min(
            max(int(round(self.negative_count * min(max(args.shared_negative_ratio, 0.0), 1.0))), 0),
            self.negative_count,
        )
        self.prefix_buckets = {}
        for item_index, token_tuple in enumerate(self.item_token_tuples):
            for prefix_length in range(1, self.max_shared_prefix + 1):
                self.prefix_buckets.setdefault(token_tuple[:prefix_length], []).append(item_index)
        self.generator = np.random.default_rng(args.seed)
        self.resample_negatives(seed=args.seed)

    def _longest_common_prefix(self, first, second):
        length = 0
        maximum = min(len(first), len(second), self.item_token_length - 1)
        for position in range(maximum):
            if first[position] != second[position]:
                break
            length += 1
        return min(length, self.max_code_prefix_length)

    def _uniform_sample(self, positive, count):
        sampled = []
        while len(sampled) < count:
            candidate = int(self.generator.integers(0, len(self.item_token_tuples)))
            if self.item_token_tuples[candidate] != positive:
                sampled.append(candidate)
        return sampled

    def _shared_prefix_sample(self, positive, count):
        if count <= 0 or self.max_shared_prefix <= 0:
            return []
        prefix_lengths = list(range(self.max_shared_prefix, self.min_shared_prefix - 1, -1))
        sampled = []
        while len(sampled) < count:
            added = False
            for prefix_length in prefix_lengths:
                candidates = [
                    item_index
                    for item_index in self.prefix_buckets.get(positive[:prefix_length], [])
                    if self.item_token_tuples[item_index] != positive
                ]
                if candidates:
                    sampled.append(candidates[int(self.generator.integers(0, len(candidates)))])
                    added = True
                    if len(sampled) == count:
                        break
            if not added:
                break
        return sampled

    def _sample_one(self, index):
        positive = tuple(self.positive_token_ids[index].tolist())
        negative_indices = self._shared_prefix_sample(positive, self.shared_negative_count)
        negative_indices.extend(
            self._uniform_sample(positive, self.negative_count - len(negative_indices))
        )
        shared_lengths = [
            self._longest_common_prefix(positive, self.item_token_tuples[item_index])
            for item_index in negative_indices
        ]
        divergence_positions = [length + 1 for length in shared_lengths]
        return negative_indices, shared_lengths, divergence_positions

    def resample_negatives(self, generator=None, seed=None):
        if generator is not None:
            seed = int(generator.initial_seed() % (2**32))
        if seed is not None:
            self.generator = np.random.default_rng(int(seed % (2**32)))
        samples = [self._sample_one(index) for index in range(len(self.examples))]
        self.negative_indices = np.asarray([sample[0] for sample in samples], dtype=np.int64)
        self.shared_lengths = np.asarray([sample[1] for sample in samples], dtype=np.int64)
        self.divergence_positions = np.asarray([sample[2] for sample in samples], dtype=np.int64)

    def __getitem__(self, index):
        example = dict(self.examples[index])
        example["negative_ids"] = self.item_token_ids[self.negative_indices[index]]
        example["shared_lengths"] = torch.tensor(self.shared_lengths[index], dtype=torch.long)
        example["divergence_positions"] = torch.tensor(
            self.divergence_positions[index], dtype=torch.long
        )
        return example
