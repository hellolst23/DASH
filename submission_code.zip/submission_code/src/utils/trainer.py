import torch
from torch.utils.data import DataLoader
from typing import Optional
from transformers import Trainer
from transformers.utils import is_torch_xla_available
from transformers.trainer_utils import SaveStrategy, EvalLoopOutput
from utils.collator import EvaluationCollator
from utils.common import constrained_tokens
from utils.trie import Trie

if is_torch_xla_available():
    import torch_xla.core.xla_model as xm

class CustomTrainer(Trainer):
    def __init__(
        self,
        *args,
        generation_eval_num_beams: int = 20,
        generation_eval_batch_size: Optional[int] = None,
        generation_eval_max_new_tokens: Optional[int] = None,
        generation_eval_enabled: bool = True,
        generation_eval_constrained: bool = True,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.generation_eval_num_beams = generation_eval_num_beams
        self.generation_eval_batch_size = generation_eval_batch_size
        self.generation_eval_max_new_tokens = generation_eval_max_new_tokens
        self.generation_eval_enabled = generation_eval_enabled
        self.generation_eval_constrained = generation_eval_constrained
        self._generation_eval_trie = None

    def _get_eval_tokenizer(self):
        tokenizer = getattr(self, "processing_class", None)
        if tokenizer is None:
            tokenizer = getattr(self, "tokenizer", None)
        return tokenizer

    def _unwrap_generation_model(self):
        if hasattr(self, "accelerator") and self.accelerator is not None:
            return self.accelerator.unwrap_model(self.model)
        if hasattr(self.model, "module"):
            return self.model.module
        return self.model

    def _get_generation_eval_trie(self, eval_dataset, tokenizer):
        if self._generation_eval_trie is not None:
            return self._generation_eval_trie
        all_items = eval_dataset.get_all_items()
        self._generation_eval_trie = Trie(
            [
                [0] + tokenizer.encode(candidate)
                for candidate in all_items
            ]
        )
        return self._generation_eval_trie

    def _compute_generation_hit_at_k(self, eval_dataset, k: int) -> Optional[float]:
        if not self.generation_eval_enabled:
            return None
        tokenizer = self._get_eval_tokenizer()
        if tokenizer is None or eval_dataset is None or not hasattr(eval_dataset, "get_all_items"):
            return None

        gen_model = self._unwrap_generation_model()
        device = next(gen_model.parameters()).device
        was_training = gen_model.training
        gen_model.eval()

        if self.generation_eval_constrained:
            candidate_trie = self._get_generation_eval_trie(eval_dataset, tokenizer)
            prefix_allowed_tokens = constrained_tokens(candidate_trie)
        else:
            prefix_allowed_tokens = None

        eval_batch_size = self.generation_eval_batch_size or self.args.per_device_eval_batch_size
        eval_collator = EvaluationCollator(tokenizer)
        eval_loader = DataLoader(
            eval_dataset,
            batch_size=eval_batch_size,
            collate_fn=eval_collator,
            shuffle=False,
            num_workers=self.args.dataloader_num_workers,
            pin_memory=True,
        )

        max_new_tokens = self.generation_eval_max_new_tokens or 5
        hit_count = 0
        total = 0
        with torch.no_grad():
            for batch in eval_loader:
                inputs, targets = batch
                inputs = {key: value.to(device) for key, value in inputs.items() if isinstance(value, torch.Tensor)}
                output = gen_model.generate(
                    input_ids=inputs["input_ids"],
                    attention_mask=inputs["attention_mask"],
                    max_new_tokens=max_new_tokens,
                    prefix_allowed_tokens_fn=prefix_allowed_tokens,
                    num_beams=k,
                    num_return_sequences=k,
                    output_scores=True,
                    return_dict_in_generate=True,
                    early_stopping=True,
                    pad_token_id=tokenizer.eos_token_id,
                )
                output_ids = output["sequences"]
                decoded_output = tokenizer.batch_decode(output_ids, skip_special_tokens=True)
                decoded_output = [item.strip().replace(" ", "") for item in decoded_output]
                for idx, target in enumerate(targets):
                    topk_items = decoded_output[idx * k: (idx + 1) * k]
                    hit_count += int(target in topk_items)
                    total += 1

        if was_training:
            gen_model.train()
        return hit_count / total if total > 0 else 0.0
    
    def _maybe_log_save_evaluate(
        self, tr_loss, grad_norm, model, trial, epoch, ignore_keys_for_eval, start_time, learning_rate=None
    ):
        if self.control.should_log and self.state.global_step > self._globalstep_last_logged:
            if is_torch_xla_available():
                xm.mark_step()

            logs: dict[str, float] = {}

            
            tr_loss_scalar = self._nested_gather(tr_loss).mean().item()

            
            tr_loss -= tr_loss

            logs["loss"] = round(tr_loss_scalar / (self.state.global_step - self._globalstep_last_logged), 4)
            if grad_norm is not None:
                logs["grad_norm"] = grad_norm.item() if isinstance(grad_norm, torch.Tensor) else grad_norm
            if learning_rate is not None:
                logs["learning_rate"] = learning_rate
            else:
                logs["learning_rate"] = self._get_learning_rate()
            
            
            assert model.training
            
            if hasattr(model, "softmax_ce_loss"):
                logs["softmax_ce_loss"] = model.softmax_ce_loss.item()
            if hasattr(model, "weighted_prefix_loss"):
                logs["weighted_prefix_loss"] = model.weighted_prefix_loss.item()

            if hasattr(model, "prefix_losses"):
                for i, l in enumerate(model.prefix_losses):
                    logs[f"prefix_loss_{i+1}"] = l.item() if l is not None and isinstance(l, torch.Tensor) else None
                    
            if hasattr(model, "prefix_avg_auc"):
                for i in range(len(model.prefix_avg_auc)):
                    logs[f"prefix_avg_auc_{i+1}"] = model.prefix_avg_auc[i] if model.prefix_avg_auc[i] is not None else None
                    logs[f"prefix_avg_mrr_{i+1}"] = model.prefix_avg_mrr[i] if model.prefix_avg_mrr[i] is not None else None

            for attr, prefix in [
                ("prefix_shared_losses", "prefix_shared_loss"),
                ("prefix_divergence_losses", "prefix_divergence_loss"),
                ("prefix_path_losses", "prefix_path_loss"),
            ]:
                if hasattr(model, attr):
                    for i, l in enumerate(getattr(model, attr)):
                        logs[f"{prefix}_{i+1}"] = l.item() if l is not None and isinstance(l, torch.Tensor) else None
            if hasattr(model, "average_shared_prefix"):
                logs["average_shared_prefix"] = model.average_shared_prefix
             
            if hasattr(model, "adaptive_weights"):
                for i, w in enumerate(model.adaptive_weights):
                    logs[f"adaptive_step_weight_{i+1}"] = w if w is not None else None

            for attr, prefix in [
                ("prefix_lambda_shared", "lambda_shared"),
                ("prefix_lambda_divergence", "lambda_divergence"),
                ("prefix_lambda_path", "lambda_path"),
                ("prefix_div_margins", "dynamic_margin_div"),
                ("prefix_path_margins", "dynamic_margin_path"),
                ("margin_div_zero_probs", "margin_div_zero_prob"),
                ("margin_div_param1s", "margin_div_param1"),
                ("margin_div_param2s", "margin_div_param2"),
                ("margin_path_zero_probs", "margin_path_zero_prob"),
                ("margin_path_param1s", "margin_path_param1"),
                ("margin_path_param2s", "margin_path_param2"),
            ]:
                if hasattr(model, attr):
                    for i, v in enumerate(getattr(model, attr)):
                        logs[f"{prefix}_{i+1}"] = v

            self._total_loss_scalar += tr_loss_scalar
            self._globalstep_last_logged = self.state.global_step
            self.store_flos()

            self.log(logs, start_time)

        metrics = None
        if self.control.should_evaluate:
            metrics = self._evaluate(trial, ignore_keys_for_eval)
            is_new_best_metric = self._determine_best_metric(metrics=metrics, trial=trial)

            if self.args.save_strategy == SaveStrategy.BEST:
                self.control.should_save = is_new_best_metric

        if self.control.should_save:
            self._save_checkpoint(model, trial)
            self.control = self.callback_handler.on_save(self.args, self.state, self.control)
    
    def evaluation_loop(
        self,
        dataloader: DataLoader,
        description: str,
        prediction_loss_only: Optional[bool] = None,
        ignore_keys: Optional[list[str]] = None,
        metric_key_prefix: str = "eval",
    ) -> EvalLoopOutput:
        output = super().evaluation_loop(
            dataloader=dataloader,
            description=description,
            prediction_loss_only=prediction_loss_only,
            ignore_keys=ignore_keys,
            metric_key_prefix=metric_key_prefix,
        )
        hit_at_k = self._compute_generation_hit_at_k(dataloader.dataset, self.generation_eval_num_beams)
        if hit_at_k is not None:
            output.metrics[f"{metric_key_prefix}_hit@{self.generation_eval_num_beams}"] = hit_at_k
        if hasattr(self.model, "softmax_ce_loss"):
            output.metrics[f"{metric_key_prefix}_softmax_ce_loss"] = self.model.softmax_ce_loss.item()
        if hasattr(self.model, "weighted_prefix_loss"):
            output.metrics[f"{metric_key_prefix}_weighted_prefix_loss"] = self.model.weighted_prefix_loss.item()

        if hasattr(self.model, "prefix_losses"):
            for i, l in enumerate(self.model.prefix_losses):
                output.metrics.update({
                    f"{metric_key_prefix}_prefix_loss_{i+1}": l.item() if l is not None and isinstance(l, torch.Tensor) else None,
                })
        if hasattr(self.model, "prefix_avg_auc"):
            for i in range(len(self.model.prefix_avg_auc)):
                output.metrics.update({
                    f"{metric_key_prefix}_prefix_avg_auc_{i+1}": self.model.prefix_avg_auc[i] if self.model.prefix_avg_auc[i] is not None else None,
                    f"{metric_key_prefix}_prefix_avg_mrr_{i+1}": self.model.prefix_avg_mrr[i] if self.model.prefix_avg_mrr[i] is not None else None,
                })
        for attr, prefix in [
            ("prefix_shared_losses", "prefix_shared_loss"),
            ("prefix_divergence_losses", "prefix_divergence_loss"),
            ("prefix_path_losses", "prefix_path_loss"),
        ]:
            if hasattr(self.model, attr):
                for i, l in enumerate(getattr(self.model, attr)):
                    output.metrics.update({
                        f"{metric_key_prefix}_{prefix}_{i+1}": l.item() if l is not None and isinstance(l, torch.Tensor) else None,
                    })
        if hasattr(self.model, "average_shared_prefix"):
            output.metrics[f"{metric_key_prefix}_average_shared_prefix"] = self.model.average_shared_prefix
        if hasattr(self.model, "adaptive_weights"):
            for i, w in enumerate(self.model.adaptive_weights):
                output.metrics.update({
                    f"{metric_key_prefix}_adaptive_step_weight_{i+1}": w if w is not None else None
                })
        for attr, prefix in [
            ("prefix_lambda_shared", "lambda_shared"),
            ("prefix_lambda_divergence", "lambda_divergence"),
            ("prefix_lambda_path", "lambda_path"),
            ("prefix_div_margins", "dynamic_margin_div"),
            ("prefix_path_margins", "dynamic_margin_path"),
            ("margin_div_zero_probs", "margin_div_zero_prob"),
            ("margin_div_param1s", "margin_div_param1"),
            ("margin_div_param2s", "margin_div_param2"),
            ("margin_path_zero_probs", "margin_path_zero_prob"),
            ("margin_path_param1s", "margin_path_param1"),
            ("margin_path_param2s", "margin_path_param2"),
        ]:
            if hasattr(self.model, attr):
                for i, v in enumerate(getattr(self.model, attr)):
                    output.metrics.update({
                        f"{metric_key_prefix}_{prefix}_{i+1}": v
                    })
        return output
        
