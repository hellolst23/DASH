import torch
from torch.nn import CrossEntropyLoss
import torch.nn.functional as F
from transformers.models.t5.configuration_t5 import T5Config
from transformers.models.t5.modeling_t5 import (
    T5ForConditionalGeneration, __HEAD_MASK_WARNING_MSG
)
import warnings
from typing import Optional, Tuple, Union
from transformers.modeling_outputs import BaseModelOutput, Seq2SeqLMOutput

def distributed_mean(tensor: torch.Tensor) -> torch.Tensor:
    if torch.distributed.is_available() and torch.distributed.is_initialized():
        tensor = tensor.clone()
        torch.distributed.all_reduce(tensor, op=torch.distributed.ReduceOp.SUM)
        tensor = tensor / torch.distributed.get_world_size()
    return tensor

class DASH(T5ForConditionalGeneration):

    @staticmethod
    def add_model_args(parser):
        parser.add_argument("--negative_count", type=int, default=100)
        parser.add_argument("--shared_negative_ratio", type=float, default=0.8)
        parser.add_argument("--min_shared_prefix", type=int, default=1)
        parser.add_argument("--max_shared_prefix", type=int, default=-1)
     
        parser.add_argument("--beta", type=float, default=0.2, help="Weight for the DASH auxiliary loss")
        parser.add_argument("--ce_tau", type=float, default=1.0, help="Temperature for cross-entropy loss")
        parser.add_argument("--prefix_tau", type=float, default=1.0, help="Temperature for DASH contrast losses")
        parser.add_argument("--base_margin", type=float, default=0.0, help="Margin for divergence and post-divergence contrast")
        parser.add_argument("--shared_prefix_weight", type=float, default=0.5, help="Weight for shared-prefix survival")
        parser.add_argument("--divergence_weight", type=float, default=1.0, help="Weight for divergence-token contrast")
        parser.add_argument("--path_contrast_weight", type=float, default=1.0, help="Weight for post-divergence prefix path contrast")
        parser.add_argument("--eta_adapt", type=float, default=3e-5, help="Eta for adaptive loss weight")
        parser.add_argument("--adaptive_lambda_mode", type=str, default="mwu", choices=["fixed", "mwu"], help="Adaptive lambda mode for shared/div/path losses")
        parser.add_argument("--lambda_adapt_eta", type=float, default=1e-3, help="Eta for shared/div/path multiplicative lambda updates")
        parser.add_argument("--lambda_ema", type=float, default=0.05, help="EMA rate for shared/div/path loss normalization")
        parser.add_argument("--lambda_min", type=float, default=0.02, help="Minimum absolute lambda value for each shared/div/path component")
        parser.add_argument("--margin_distribution", type=str, default="gamma", choices=["fixed", "gaussian", "chisquare", "gamma", "lognormal", "empirical"], help="Distribution-aware dynamic margin mode")
        parser.add_argument("--margin_quantiles", type=str, default="0.80,0.82,0.85,0.88", help="Per-step target quantiles for dynamic margins")
        parser.add_argument("--margin_ema", type=float, default=0.05, help="EMA rate for violation distribution fitting")
        parser.add_argument("--margin_min", type=float, default=0.0, help="Lower bound for dynamic margins")
        parser.add_argument("--margin_max", type=float, default=1.0, help="Upper bound for dynamic margins")
        parser.add_argument("--margin_std_floor", type=float, default=1e-4, help="Minimum std for gaussian margin fitting")
        parser.add_argument("--margin_apply_mode", type=str, default="losing_only", choices=["all", "losing_only", "near_boundary"], help="Which pairs receive the dynamic margin inside div/path softplus")
        parser.add_argument("--margin_gate_slack", type=float, default=0.0, help="For near_boundary mode, apply margin when neg_score - pos_score >= -slack")
        parser.add_argument("--margin_value_ema", type=float, default=0.05, help="EMA rate for final dynamic margin values")
        parser.add_argument("--margin_delta_max", type=float, default=0.1, help="Maximum per-update increase for final dynamic margins; <=0 disables the cap")
        parser.add_argument("--margin_warmup_epochs", type=float, default=5.0, help="Epochs used to warm distribution-aware margin strength")
        parser.add_argument("--chi2_df_min", type=float, default=1.0, help="Minimum degrees of freedom for chi-square margin fitting")
        parser.add_argument("--chi2_df_max", type=float, default=50.0, help="Maximum degrees of freedom for chi-square margin fitting")
        return parser

    def __init__(
        self, 
        config: T5Config,
        args: Optional[object] = None,
    ):
        super().__init__(config)
        self.beta = getattr(args, "beta", 0.2)
        self.ce_tau = getattr(args, "ce_tau", 1.0)
        self.prefix_tau = getattr(args, "prefix_tau", 1.0)
        self.base_margin = getattr(args, "base_margin", 0.0)
        self.shared_prefix_weight = getattr(args, "shared_prefix_weight", 0.5)
        self.divergence_weight = getattr(args, "divergence_weight", 1.0)
        self.path_contrast_weight = getattr(args, "path_contrast_weight", 1.0)
        self.eta_adapt = getattr(args, "eta_adapt", 3e-5)
        self.adaptive_lambda_mode = getattr(args, "adaptive_lambda_mode", "mwu")
        self.lambda_adapt_eta = getattr(args, "lambda_adapt_eta", 1e-3)
        self.lambda_ema = getattr(args, "lambda_ema", 0.05)
        self.lambda_min = getattr(args, "lambda_min", 0.02)
        self.margin_distribution = getattr(args, "margin_distribution", "gamma")
        self.margin_quantiles = self._parse_step_values(getattr(args, "margin_quantiles", "0.80,0.82,0.85,0.88"))
        self.margin_ema = getattr(args, "margin_ema", 0.05)
        self.margin_min = getattr(args, "margin_min", 0.0)
        self.margin_max = getattr(args, "margin_max", 1.0)
        self.margin_std_floor = getattr(args, "margin_std_floor", 1e-4)
        self.margin_apply_mode = getattr(args, "margin_apply_mode", "losing_only")
        self.margin_gate_slack = getattr(args, "margin_gate_slack", 0.0)
        self.margin_value_ema = getattr(args, "margin_value_ema", 0.05)
        self.margin_delta_max = getattr(args, "margin_delta_max", 0.1)
        self.margin_warmup_epochs = getattr(args, "margin_warmup_epochs", 5.0)
        self.chi2_df_min = getattr(args, "chi2_df_min", 1.0)
        self.chi2_df_max = getattr(args, "chi2_df_max", 50.0)
        self.last_w = None
        self.lambda_state = None
        self.lambda_loss_ema = None
        self.current_epoch = 0.0
        self.chi2_stats = {}
        self.gaussian_stats = {}
        self.lognormal_stats = {}
        self.empirical_stats = {}
        self.margin_value_stats = {}
        self.valid_prefix_num = None

    def set_valid_prefix_num(self, valid_prefix_num):
        self.valid_prefix_num = valid_prefix_num

    def set_train_epoch(self, epoch):
        self.current_epoch = 0.0 if epoch is None else float(epoch)

    @staticmethod
    def _parse_step_values(value):
        if isinstance(value, (list, tuple)):
            return [float(v) for v in value]
        return [float(v.strip()) for v in str(value).split(",") if v.strip()]

    def _step_value(self, values, t):
        if not values:
            return 0.5
        return values[min(t - 1, len(values) - 1)]

    def _base_lambdas(self, num_steps, device):
        base = torch.tensor(
            [self.shared_prefix_weight, self.divergence_weight, self.path_contrast_weight],
            device=device,
            dtype=torch.float32,
        )
        return base.unsqueeze(0).expand(num_steps, -1).clone()

    def _adaptive_lambdas(self, component_losses):
        num_steps = component_losses.size(0)
        device = component_losses.device
        base = self._base_lambdas(num_steps, device)
        total = base.sum(dim=-1, keepdim=True).clamp_min(1e-12)

        if self.adaptive_lambda_mode == "fixed":
            self.lambda_state = base.detach()
            return base

        loss_stats = torch.nan_to_num(distributed_mean(component_losses.detach()), nan=0.0, posinf=0.0, neginf=0.0)
        if self.lambda_loss_ema is None or self.lambda_loss_ema.shape != loss_stats.shape:
            loss_ema = loss_stats
        else:
            prev = self.lambda_loss_ema.to(device)
            eta = float(self.lambda_ema)
            loss_ema = (1.0 - eta) * prev + eta * loss_stats

        if self.lambda_state is None or self.lambda_state.shape != base.shape:
            old_lambda = base
        else:
            old_lambda = self.lambda_state.to(device)

        if self.training:
            difficulty = loss_stats / loss_ema.clamp_min(1e-12)
            difficulty = torch.nan_to_num(difficulty, nan=0.0, posinf=0.0, neginf=0.0)
            updated = old_lambda * torch.exp(float(self.lambda_adapt_eta) * difficulty)
            lambdas = updated / updated.sum(dim=-1, keepdim=True).clamp_min(1e-12) * total
            min_lambda = min(max(float(self.lambda_min), 0.0), total.min().item() / 3.0)
            if min_lambda > 0:
                lambdas = lambdas.clamp_min(min_lambda)
                lambdas = lambdas / lambdas.sum(dim=-1, keepdim=True).clamp_min(1e-12) * total
            self.lambda_loss_ema = loss_ema.detach()
            self.lambda_state = lambdas.detach()
            return lambdas

        return old_lambda

    def _get_chi2_state(self, kind, num_steps, device):
        if kind not in self.chi2_stats or self.chi2_stats[kind]["mu"].numel() < num_steps:
            self.chi2_stats[kind] = {
                "pi0": torch.ones(num_steps, device=device),
                "mu": torch.zeros(num_steps, device=device),
                "var": torch.ones(num_steps, device=device),
                "initialized": torch.zeros(num_steps, device=device, dtype=torch.bool),
            }
        else:
            self.chi2_stats[kind] = {k: v.to(device) for k, v in self.chi2_stats[kind].items()}
        return self.chi2_stats[kind]

    def _get_gaussian_state(self, kind, num_steps, device):
        if kind not in self.gaussian_stats or self.gaussian_stats[kind]["mu"].numel() < num_steps:
            self.gaussian_stats[kind] = {
                "mu": torch.zeros(num_steps, device=device),
                "std": torch.ones(num_steps, device=device),
                "initialized": torch.zeros(num_steps, device=device, dtype=torch.bool),
            }
        else:
            self.gaussian_stats[kind] = {k: v.to(device) for k, v in self.gaussian_stats[kind].items()}
        return self.gaussian_stats[kind]

    def _get_lognormal_state(self, kind, num_steps, device):
        if kind not in self.lognormal_stats or self.lognormal_stats[kind]["mu"].numel() < num_steps:
            self.lognormal_stats[kind] = {
                "pi0": torch.ones(num_steps, device=device),
                "mu": torch.zeros(num_steps, device=device),
                "std": torch.ones(num_steps, device=device),
                "initialized": torch.zeros(num_steps, device=device, dtype=torch.bool),
            }
        else:
            self.lognormal_stats[kind] = {k: v.to(device) for k, v in self.lognormal_stats[kind].items()}
        return self.lognormal_stats[kind]

    def _get_empirical_state(self, kind, num_steps, device):
        if kind not in self.empirical_stats or self.empirical_stats[kind]["quantile"].numel() < num_steps:
            self.empirical_stats[kind] = {
                "pi0": torch.ones(num_steps, device=device),
                "quantile": torch.zeros(num_steps, device=device),
                "initialized": torch.zeros(num_steps, device=device, dtype=torch.bool),
            }
        else:
            self.empirical_stats[kind] = {k: v.to(device) for k, v in self.empirical_stats[kind].items()}
        return self.empirical_stats[kind]

    def _get_margin_value_state(self, kind, num_steps, device):
        if kind not in self.margin_value_stats or self.margin_value_stats[kind]["ema"].numel() < num_steps:
            self.margin_value_stats[kind] = {
                "ema": torch.zeros(num_steps, device=device),
                "previous": torch.zeros(num_steps, device=device),
                "initialized": torch.zeros(num_steps, device=device, dtype=torch.bool),
            }
        else:
            self.margin_value_stats[kind] = {k: v.to(device) for k, v in self.margin_value_stats[kind].items()}
        return self.margin_value_stats[kind]

    def _stabilize_margin(self, raw_margin, t, kind, num_steps):
        raw_margin = raw_margin.clamp(float(self.margin_min), float(self.margin_max))
        if not self.training:
            return raw_margin

        state = self._get_margin_value_state(kind, num_steps, raw_margin.device)
        idx = t - 1
        if not state["initialized"][idx]:
            margin_ema = raw_margin
            state["initialized"][idx] = True
        else:
            rho = float(self.margin_value_ema)
            margin_ema = (1.0 - rho) * state["ema"][idx] + rho * raw_margin

        delta_max = float(self.margin_delta_max)
        if delta_max > 0:
            margin_ema = torch.minimum(margin_ema, state["previous"][idx] + delta_max)

        margin = margin_ema.clamp(float(self.margin_min), float(self.margin_max))
        state["ema"][idx] = margin.detach()
        state["previous"][idx] = margin.detach()
        return margin

    def _chi_square_inverse_approx(self, q, df):
        normal = torch.distributions.Normal(q.new_tensor(0.0), q.new_tensor(1.0))
        z = normal.icdf(q.clamp(1e-4, 1.0 - 1e-4))
        base = 1.0 - 2.0 / (9.0 * df) + z * torch.sqrt(2.0 / (9.0 * df))
        return df * base.clamp_min(0.0).pow(3)

    def _effective_margin(self, score_gap, margin):
        if self.margin_apply_mode == "all":
            return margin
        if self.margin_apply_mode == "near_boundary":
            gate = score_gap.detach() >= -float(self.margin_gate_slack)
        else:
            gate = score_gap.detach() > 0.0
        return margin * gate.to(score_gap.dtype)

    def _zero_inflated_positive_quantile(self, target_q, pi0, positive_quantile):
        return torch.where(target_q <= pi0, target_q.new_tensor(0.0), positive_quantile)

    def _distributed_margin_stats(self, flat, eps):
        positive = flat[flat > eps]
        log_positive = positive.clamp_min(eps).log()
        stats = torch.stack(
            [
                flat.new_tensor(float(flat.numel())),
                (flat <= eps).sum().to(flat.dtype),
                flat.sum(),
                flat.square().sum(),
                flat.new_tensor(float(positive.numel())),
                positive.sum(),
                positive.square().sum(),
                log_positive.sum(),
                log_positive.square().sum(),
            ]
        )
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            torch.distributed.all_reduce(stats, op=torch.distributed.ReduceOp.SUM)
        return stats

    def _distributed_available_mean(self, value, available):
        stats = torch.stack([value, value.new_tensor(float(available))])
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            torch.distributed.all_reduce(stats, op=torch.distributed.ReduceOp.SUM)
        return stats[0] / stats[1].clamp_min(1.0)

    def _dynamic_margin(self, violations, t, kind, num_steps):
        device = violations.device
        base_margin = violations.new_tensor(float(self.base_margin))
        if self.margin_distribution == "fixed":
            return base_margin, violations.new_tensor(0.0), violations.new_tensor(0.0), violations.new_tensor(0.0)

        flat = violations.detach().reshape(-1)
        flat = flat[torch.isfinite(flat)]
        target_q = violations.new_tensor(self._step_value(self.margin_quantiles, t)).clamp(1e-4, 1.0 - 1e-4)
        warm_den = max(float(self.margin_warmup_epochs), 1e-6)
        warm = min(1.0, max(0.0, (float(self.current_epoch) + 1.0) / warm_den))
        eps = 1e-12
        stats = self._distributed_margin_stats(flat, eps)
        count = stats[0]
        if count <= 0:
            return base_margin, violations.new_tensor(1.0), violations.new_tensor(0.0), violations.new_tensor(0.0)

        if self.margin_distribution == "gaussian":
            batch_mu = stats[2] / count
            batch_var = (stats[3] / count - batch_mu.square()).clamp_min(0.0)
            batch_std = batch_var.sqrt().clamp_min(float(self.margin_std_floor))
            state = self._get_gaussian_state(kind, num_steps, device)
            idx = t - 1
            if self.training:
                if not state["initialized"][idx]:
                    state["mu"][idx] = batch_mu
                    state["std"][idx] = batch_std
                    state["initialized"][idx] = True
                else:
                    eta = float(self.margin_ema)
                    state["mu"][idx] = (1.0 - eta) * state["mu"][idx] + eta * batch_mu
                    state["std"][idx] = (1.0 - eta) * state["std"][idx] + eta * batch_std

            mu = state["mu"][idx]
            std = state["std"][idx].clamp_min(float(self.margin_std_floor))
            normal = torch.distributions.Normal(violations.new_tensor(0.0), violations.new_tensor(1.0))
            z = normal.icdf(target_q)
            raw_margin = base_margin + warm * (mu + std * z)
            dynamic_margin = self._stabilize_margin(raw_margin, t, kind, num_steps)
            return dynamic_margin, violations.new_tensor(0.0), mu.detach(), std.detach()

        pi0_batch = stats[1] / count
        positive = flat[flat > eps]

        if self.margin_distribution == "empirical":
            if positive.numel() == 0:
                batch_quantile = violations.new_tensor(0.0)
            else:
                q_prime_batch = ((target_q - pi0_batch.clamp(0.0, 1.0 - 1e-4)) / (1.0 - pi0_batch).clamp_min(1e-4)).clamp(1e-4, 1.0 - 1e-4)
                batch_quantile = torch.quantile(positive, q_prime_batch)
            batch_quantile = self._distributed_available_mean(
                batch_quantile,
                positive.numel() > 0,
            )

            state = self._get_empirical_state(kind, num_steps, device)
            idx = t - 1
            if self.training:
                if not state["initialized"][idx]:
                    state["pi0"][idx] = pi0_batch
                    state["quantile"][idx] = batch_quantile
                    state["initialized"][idx] = True
                else:
                    eta = float(self.margin_ema)
                    state["pi0"][idx] = (1.0 - eta) * state["pi0"][idx] + eta * pi0_batch
                    state["quantile"][idx] = (1.0 - eta) * state["quantile"][idx] + eta * batch_quantile

            pi0 = state["pi0"][idx].clamp(0.0, 1.0)
            raw_positive = state["quantile"][idx].clamp_min(0.0)
            raw_margin = base_margin + warm * self._zero_inflated_positive_quantile(target_q, pi0, raw_positive)
            dynamic_margin = self._stabilize_margin(raw_margin, t, kind, num_steps)
            return dynamic_margin, pi0.detach(), raw_positive.detach(), violations.new_tensor(0.0)

        if self.margin_distribution == "lognormal":
            positive_count = stats[4]
            if positive_count <= 0:
                log_mu_batch = violations.new_tensor(0.0)
                log_std_batch = violations.new_tensor(float(self.margin_std_floor))
            else:
                log_mu_batch = stats[7] / positive_count
                log_var_batch = (stats[8] / positive_count - log_mu_batch.square()).clamp_min(0.0)
                log_std_batch = log_var_batch.sqrt().clamp_min(float(self.margin_std_floor))

            state = self._get_lognormal_state(kind, num_steps, device)
            idx = t - 1
            if self.training:
                if not state["initialized"][idx]:
                    state["pi0"][idx] = pi0_batch
                    state["mu"][idx] = log_mu_batch
                    state["std"][idx] = log_std_batch
                    state["initialized"][idx] = True
                else:
                    eta = float(self.margin_ema)
                    state["pi0"][idx] = (1.0 - eta) * state["pi0"][idx] + eta * pi0_batch
                    state["mu"][idx] = (1.0 - eta) * state["mu"][idx] + eta * log_mu_batch
                    state["std"][idx] = (1.0 - eta) * state["std"][idx] + eta * log_std_batch

            pi0 = state["pi0"][idx].clamp(0.0, 1.0 - 1e-4)
            q_prime = ((target_q - pi0) / (1.0 - pi0).clamp_min(1e-4)).clamp(1e-4, 1.0 - 1e-4)
            normal = torch.distributions.Normal(violations.new_tensor(0.0), violations.new_tensor(1.0))
            z = normal.icdf(q_prime)
            positive_quantile = (state["mu"][idx] + state["std"][idx].clamp_min(float(self.margin_std_floor)) * z).exp()
            raw_margin = base_margin + warm * self._zero_inflated_positive_quantile(target_q, pi0, positive_quantile)
            dynamic_margin = self._stabilize_margin(raw_margin, t, kind, num_steps)
            return dynamic_margin, pi0.detach(), state["mu"][idx].detach(), state["std"][idx].detach()

        positive_count = stats[4]
        if positive_count <= 0:
            mu_batch = violations.new_tensor(0.0)
            var_batch = violations.new_tensor(1.0)
        else:
            mu_batch = stats[5] / positive_count
            var_batch = (stats[6] / positive_count - mu_batch.square()).clamp_min(eps)

        state = self._get_chi2_state(kind, num_steps, device)
        idx = t - 1
        if self.training:
            if not state["initialized"][idx]:
                state["pi0"][idx] = pi0_batch
                state["mu"][idx] = mu_batch
                state["var"][idx] = var_batch
                state["initialized"][idx] = True
            else:
                eta = float(self.margin_ema)
                state["pi0"][idx] = (1.0 - eta) * state["pi0"][idx] + eta * pi0_batch
                state["mu"][idx] = (1.0 - eta) * state["mu"][idx] + eta * mu_batch
                state["var"][idx] = (1.0 - eta) * state["var"][idx] + eta * var_batch

        pi0 = state["pi0"][idx].clamp(0.0, 1.0 - 1e-4)
        mu = state["mu"][idx].clamp_min(0.0)
        var = state["var"][idx].clamp_min(eps)
        df = (2.0 * mu.pow(2) / var).clamp(float(self.chi2_df_min), float(self.chi2_df_max))
        scale = (var / (2.0 * mu.clamp_min(eps))).clamp_min(0.0)

        q_prime = ((target_q - pi0) / (1.0 - pi0).clamp_min(1e-4)).clamp(1e-4, 1.0 - 1e-4)
        chi_quantile = self._chi_square_inverse_approx(q_prime, df)
        positive_quantile = scale * chi_quantile
        raw_margin = base_margin + warm * self._zero_inflated_positive_quantile(target_q, pi0, positive_quantile)
        dynamic_margin = self._stabilize_margin(raw_margin, t, kind, num_steps)
        return dynamic_margin, pi0.detach(), df.detach(), scale.detach()

    def forward(
        self,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        decoder_input_ids: Optional[torch.LongTensor] = None,
        decoder_attention_mask: Optional[torch.BoolTensor] = None,
        head_mask: Optional[torch.FloatTensor] = None,
        decoder_head_mask: Optional[torch.FloatTensor] = None,
        cross_attn_head_mask: Optional[torch.Tensor] = None,
        encoder_outputs: Optional[Tuple[Tuple[torch.Tensor]]] = None,
        past_key_values: Optional[Tuple[Tuple[torch.Tensor]]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        decoder_inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        cache_position: Optional[torch.LongTensor] = None,
        labels_with_negs: Optional[torch.LongTensor] = None,
        labels_with_negs_prefix_mask: Optional[torch.BoolTensor] = None,
        negative_shared_lengths: Optional[torch.LongTensor] = None,
        negative_divergence_positions: Optional[torch.LongTensor] = None,
        return_neg_logits: Optional[bool] = False,
        **kwargs,
    ) -> Union[Tuple[torch.FloatTensor], Seq2SeqLMOutput]:

        use_cache = use_cache if use_cache is not None else self.config.use_cache
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        
        if head_mask is not None and decoder_head_mask is None:
            if self.config.num_layers == self.config.num_decoder_layers:
                warnings.warn(__HEAD_MASK_WARNING_MSG, FutureWarning)
                decoder_head_mask = head_mask

        
        if encoder_outputs is None:
            
            encoder_outputs = self.encoder(
                input_ids=input_ids,
                attention_mask=attention_mask,
                inputs_embeds=inputs_embeds,
                head_mask=head_mask,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
            )
        elif return_dict and not isinstance(encoder_outputs, BaseModelOutput):
            encoder_outputs = BaseModelOutput(
                last_hidden_state=encoder_outputs[0],
                hidden_states=encoder_outputs[1] if len(encoder_outputs) > 1 else None,
                attentions=encoder_outputs[2] if len(encoder_outputs) > 2 else None,
            )

        hidden_states = encoder_outputs[0]

        if self.model_parallel:
            torch.cuda.set_device(self.decoder.first_device)

        if labels_with_negs is not None:
            prefix_shared_losses = []
            prefix_divergence_losses = []
            prefix_path_losses = []
            prefix_div_margins = []
            prefix_path_margins = []
            margin_div_zero_probs = []
            margin_div_param1s = []
            margin_div_param2s = []
            margin_path_zero_probs = []
            margin_path_param1s = []
            margin_path_param2s = []
            prefix_avg_auc = []
            prefix_avg_mrr = []
            softmax_ce_loss = None
            assert labels is not None
            assert negative_shared_lengths is not None
            assert negative_divergence_positions is not None

            B = input_ids.shape[0]
            T = labels_with_negs.shape[1]
            repeat_factor = labels_with_negs.shape[0] // input_ids.shape[0] 
            all_encoder_hidden_states = hidden_states.repeat_interleave(repeat_factor, dim=0)
            all_encoder_attention_masks = attention_mask.repeat_interleave(repeat_factor, dim=0)
            all_decoder_input_ids = self._shift_right(labels_with_negs)

            neg_k = repeat_factor - 1

            
            candidate_decoder_outputs = self.decoder(
                input_ids=all_decoder_input_ids,
                attention_mask=None,
                encoder_hidden_states=all_encoder_hidden_states,
                encoder_attention_mask=all_encoder_attention_masks,
                use_cache=False,
                return_dict=True,
            )

            candidate_sequence_output = candidate_decoder_outputs[0]
            if self.model_parallel:
                torch.cuda.set_device(self.encoder.first_device)
                self.lm_head = self.lm_head.to(self.encoder.first_device)
                candidate_sequence_output = candidate_sequence_output.to(self.lm_head.weight.device)

            if self.config.tie_word_embeddings:
                candidate_sequence_output = candidate_sequence_output * (self.model_dim**-0.5)
            
            candidate_logits = self.lm_head(candidate_sequence_output)
            lm_logits = candidate_logits.reshape(B, neg_k + 1, T, -1)[:, 0]

            decoder_outputs = candidate_decoder_outputs

            t_logits = lm_logits / self.ce_tau
            loss_fct = CrossEntropyLoss(ignore_index=-100)
            labels = labels.to(t_logits.device)
            softmax_ce_loss = loss_fct(t_logits.reshape(-1, t_logits.size(-1)), labels.reshape(-1))

            t_candidate_logits = candidate_logits / self.ce_tau
            log_probs = F.log_softmax(t_candidate_logits, dim=-1) 
            safe_labels_with_negs = labels_with_negs.masked_fill(labels_with_negs < 0, 0)
            token_logp = torch.gather(log_probs, 2, safe_labels_with_negs.unsqueeze(-1)).squeeze(-1) 
            token_logp = token_logp.masked_fill(labels_with_negs < 0, 0.0)
            candidate_token_logp = token_logp.view(B, neg_k + 1, T)
            pos_token_logp = candidate_token_logp[:, 0, :]
            neg_token_logp = candidate_token_logp[:, 1:, :]
            candidate_label_ids = safe_labels_with_negs.view(B, neg_k + 1, T)
            neg_label_ids = candidate_label_ids[:, 1:, :].to(t_logits.device)
            negative_shared_lengths = negative_shared_lengths.to(t_logits.device)
            negative_divergence_positions = negative_divergence_positions.to(t_logits.device)
            positive_route_log_probs = F.log_softmax(t_logits, dim=-1)
            zero = pos_token_logp.sum() * 0.0
             
            
            for t in range(1, T):  
                prefix_logp = (token_logp[:, :t]).sum(dim=1)  
                score_matrix = prefix_logp.view(B, neg_k + 1)  
                prefix_avg_auc.append(self.cal_avg_auc(score_matrix))
                prefix_avg_mrr.append(self.cal_avg_mrr(score_matrix))

                shared_mask = negative_shared_lengths >= t
                shared_strength = shared_mask.float().mean(dim=-1)
                if shared_strength.sum() > 0:
                    shared_loss_t = (shared_strength * (-pos_token_logp[:, t - 1])).sum() / shared_strength.sum().clamp_min(1.0)
                else:
                    shared_loss_t = zero

                div_mask = negative_divergence_positions == t
                neg_next_token_ids = neg_label_ids[:, :, t - 1]
                neg_next_logp = torch.gather(
                    positive_route_log_probs[:, t - 1, :].unsqueeze(1).expand(-1, neg_k, -1),
                    2,
                    neg_next_token_ids.unsqueeze(-1)
                ).squeeze(-1)
                pos_next_logp = pos_token_logp[:, t - 1].unsqueeze(1)
                div_score_gap = neg_next_logp - pos_next_logp
                div_violation = div_score_gap.clamp_min(0.0)
                div_margin, div_zero_prob, div_param1, div_param2 = self._dynamic_margin(
                    div_violation[div_mask], t, "div", T - 1
                )
                if div_mask.any():
                    div_effective_margin = self._effective_margin(div_score_gap, div_margin)
                    div_terms = (div_score_gap + div_effective_margin) / self.prefix_tau
                    divergence_loss_t = F.softplus(div_terms[div_mask]).mean()
                else:
                    divergence_loss_t = zero

                path_mask = negative_divergence_positions <= t
                pos_prefix_scores = score_matrix[:, 0].unsqueeze(1)
                neg_prefix_scores = score_matrix[:, 1:]
                path_score_gap = neg_prefix_scores - pos_prefix_scores
                path_violation = path_score_gap.clamp_min(0.0)
                path_margin, path_zero_prob, path_param1, path_param2 = self._dynamic_margin(
                    path_violation[path_mask], t, "path", T - 1
                )
                if path_mask.any():
                    path_effective_margin = self._effective_margin(path_score_gap, path_margin)
                    path_terms = (path_score_gap + path_effective_margin) / self.prefix_tau
                    path_loss_t = F.softplus(path_terms[path_mask]).mean()
                else:
                    path_loss_t = zero

                prefix_shared_losses.append(shared_loss_t)
                prefix_divergence_losses.append(divergence_loss_t)
                prefix_path_losses.append(path_loss_t)
                prefix_div_margins.append(div_margin.detach().item())
                prefix_path_margins.append(path_margin.detach().item())
                margin_div_zero_probs.append(div_zero_prob.detach().item())
                margin_div_param1s.append(div_param1.detach().item())
                margin_div_param2s.append(div_param2.detach().item())
                margin_path_zero_probs.append(path_zero_prob.detach().item())
                margin_path_param1s.append(path_param1.detach().item())
                margin_path_param2s.append(path_param2.detach().item())

            component_losses = torch.stack(
                [torch.stack(prefix_shared_losses), torch.stack(prefix_divergence_losses), torch.stack(prefix_path_losses)],
                dim=-1,
            )
            lambdas = self._adaptive_lambdas(component_losses)
            all_prefix_losses = (lambdas * component_losses).sum(dim=-1)
            all_prefix_losses = torch.nan_to_num(all_prefix_losses, nan=0.0, posinf=0.0, neginf=0.0)
            prefix_losses = [loss_t for loss_t in all_prefix_losses]

            
            all_prefix_losses = torch.stack(prefix_losses)
            all_prefix_losses = torch.nan_to_num(all_prefix_losses, nan=0.0, posinf=0.0, neginf=0.0)
            base_losses = distributed_mean(all_prefix_losses.detach())

            eps = 1e-12
            if base_losses.sum() <= eps:
                w = torch.ones_like(base_losses) / base_losses.numel()
            elif self.last_w is None:
                w = base_losses / base_losses.sum()
            else:
                normed_base_losses = base_losses / base_losses.sum()
                weighted_w = self.last_w * torch.exp(self.eta_adapt * normed_base_losses)
                w = weighted_w / weighted_w.sum()

            self.last_w = w

            
            weighted_prefix_loss = (w * all_prefix_losses).sum()
            self.adaptive_weights = w.detach().cpu().tolist()

            
            self.softmax_ce_loss = softmax_ce_loss
            self.prefix_losses = prefix_losses
            self.prefix_shared_losses = prefix_shared_losses
            self.prefix_divergence_losses = prefix_divergence_losses
            self.prefix_path_losses = prefix_path_losses
            self.prefix_lambda_shared = lambdas[:, 0].detach().cpu().tolist()
            self.prefix_lambda_divergence = lambdas[:, 1].detach().cpu().tolist()
            self.prefix_lambda_path = lambdas[:, 2].detach().cpu().tolist()
            self.prefix_div_margins = prefix_div_margins
            self.prefix_path_margins = prefix_path_margins
            self.margin_div_zero_probs = margin_div_zero_probs
            self.margin_div_param1s = margin_div_param1s
            self.margin_div_param2s = margin_div_param2s
            self.margin_path_zero_probs = margin_path_zero_probs
            self.margin_path_param1s = margin_path_param1s
            self.margin_path_param2s = margin_path_param2s
            self.prefix_avg_auc = prefix_avg_auc
            self.prefix_avg_mrr = prefix_avg_mrr
            self.weighted_prefix_loss = self.beta * weighted_prefix_loss
            self.average_shared_prefix = negative_shared_lengths.float().mean().detach().item()

            loss = softmax_ce_loss + self.beta * weighted_prefix_loss

            if return_neg_logits:
                lm_logits = candidate_logits
            else:
                lm_logits = lm_logits
                
        else: 
            if labels is not None and decoder_input_ids is None and decoder_inputs_embeds is None:
                
                decoder_input_ids = self._shift_right(labels)

            
            if self.model_parallel:
                torch.cuda.set_device(self.decoder.first_device)
                hidden_states = hidden_states.to(self.decoder.first_device)
                if decoder_input_ids is not None:
                    decoder_input_ids = decoder_input_ids.to(self.decoder.first_device)
                if attention_mask is not None:
                    attention_mask = attention_mask.to(self.decoder.first_device)
                if decoder_attention_mask is not None:
                    decoder_attention_mask = decoder_attention_mask.to(self.decoder.first_device)

            decoder_outputs = self.decoder(
                input_ids=decoder_input_ids,
                attention_mask=decoder_attention_mask,
                inputs_embeds=decoder_inputs_embeds,
                past_key_values=past_key_values,
                encoder_hidden_states=hidden_states,
                encoder_attention_mask=attention_mask,
                head_mask=decoder_head_mask,
                cross_attn_head_mask=cross_attn_head_mask,
                use_cache=use_cache,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
                cache_position=cache_position,
            )

            sequence_output = decoder_outputs[0]

            
            if self.model_parallel:
                torch.cuda.set_device(self.encoder.first_device)
                self.lm_head = self.lm_head.to(self.encoder.first_device)
                sequence_output = sequence_output.to(self.lm_head.weight.device)

            if self.config.tie_word_embeddings:
                
                
                sequence_output = sequence_output * (self.model_dim**-0.5)

            lm_logits = self.lm_head(sequence_output)

            if labels is not None:
                t_logits = lm_logits / self.ce_tau
                loss_fct = CrossEntropyLoss(ignore_index=-100)
                
                labels = labels.to(t_logits.device)
                loss = loss_fct(t_logits.view(-1, t_logits.size(-1)), labels.view(-1))
            else:
                lm_logits = lm_logits
                loss = None

        if not return_dict:
            output = (lm_logits,) + decoder_outputs[1:] + encoder_outputs
            return ((loss,) + output) if loss is not None else output

        return Seq2SeqLMOutput(
            loss=loss,
            logits=lm_logits,
            past_key_values=decoder_outputs.past_key_values,
            decoder_hidden_states=decoder_outputs.hidden_states,
            decoder_attentions=decoder_outputs.attentions,
            cross_attentions=decoder_outputs.cross_attentions,
            encoder_last_hidden_state=encoder_outputs.last_hidden_state,
            encoder_hidden_states=encoder_outputs.hidden_states,
            encoder_attentions=encoder_outputs.attentions,
        )

    def cal_avg_auc(self, scores_matrix: torch.Tensor) -> float:
        pos_scores = scores_matrix[:, 0]  
        neg_scores = scores_matrix[:, 1:]  
        auc = 0.0
        for i in range(neg_scores.shape[0]):
            neg_scores_i = neg_scores[i][neg_scores[i] != float('-inf')]
            
            auc_i = (pos_scores[i] > neg_scores_i).float().mean().item()  
            auc += auc_i
        avg_auc = auc / scores_matrix.shape[0]  
        return avg_auc
    
    def cal_avg_mrr(self, scores_matrix: torch.Tensor) -> float:
        pos_scores = scores_matrix[:, 0]  
        neg_scores = scores_matrix[:, 1:]  
        mrr = 0.0
        
        for i in range(neg_scores.shape[0]):
            neg_scores_i = neg_scores[i][neg_scores[i] != float('-inf')]
            rank_i = (pos_scores[i] < neg_scores_i).float().sum().item() + 1  
            mrr += 1.0 / rank_i if rank_i > 0 else 0.0  
        
        avg_mrr = mrr / scores_matrix.shape[0]  
        return avg_mrr
