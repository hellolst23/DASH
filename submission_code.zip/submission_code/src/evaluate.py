import argparse
import os

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from models import DASH
from tokenizer import LightCodeTokenizer
from utils.collator import EvaluationCollator
from utils.common import constrained_tokens, save_json, set_seed
from utils.data import SequenceDataset
from utils.metrics import ranking_metrics
from utils.trie import Trie


def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--dataset", choices=["Office", "Grocery", "Beauty", "Yelp"], default="Office")
    parser.add_argument("--data_path", default="./data")
    parser.add_argument("--tokenizer_path", default="./config/tokenizer")
    parser.add_argument("--results_path", default="./results")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max_history_length", type=int, default=20)
    parser.add_argument("--index_suffix", default=".index.rq-kmeans.json")
    parser.add_argument("--sample_count", type=int, default=-1)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--beams", type=int, default=20)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--unconstrained", action="store_true")
    return parser


def main():
    args = build_parser().parse_args()
    set_seed(args.seed)
    device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu")
    tokenizer = LightCodeTokenizer.from_pretrained(
        os.path.join(args.tokenizer_path, args.dataset), model_max_length=512
    )
    dataset = SequenceDataset(args, "test", sample_num=args.sample_count)
    trie = Trie([[0] + tokenizer.encode(item) for item in dataset.get_all_items()])
    allowed_tokens = None if args.unconstrained else constrained_tokens(trie)
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        collate_fn=EvaluationCollator(tokenizer),
        shuffle=False,
        num_workers=args.workers,
        pin_memory=torch.cuda.is_available(),
    )
    model = DASH.from_pretrained(args.checkpoint, low_cpu_mem_usage=True).to(device)
    model.eval()
    predictions = []
    targets = []
    with torch.no_grad():
        for inputs, batch_targets in tqdm(loader):
            inputs = {name: value.to(device) for name, value in inputs.items()}
            output = model.generate(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                max_new_tokens=5,
                prefix_allowed_tokens_fn=allowed_tokens,
                num_beams=args.beams,
                num_return_sequences=args.beams,
                output_scores=True,
                return_dict_in_generate=True,
                early_stopping=True,
                pad_token_id=tokenizer.eos_token_id,
            )
            decoded = [
                value.strip().replace(" ", "")
                for value in tokenizer.batch_decode(output.sequences, skip_special_tokens=True)
            ]
            scores = output.sequences_scores.view(len(batch_targets), args.beams)
            for row in range(len(batch_targets)):
                start = row * args.beams
                candidates = decoded[start:start + args.beams]
                order = torch.argsort(scores[row], descending=True).tolist()
                predictions.append([candidates[index] for index in order])
            targets.extend(batch_targets)
    cutoffs = sorted({10, args.beams})
    metrics = ranking_metrics(predictions, targets, cutoffs)
    result_path = os.path.join(args.results_path, args.dataset, "metrics.json")
    save_json({"model": "DASH", "dataset": args.dataset, "metrics": metrics}, result_path)
    print(metrics)


if __name__ == "__main__":
    main()
