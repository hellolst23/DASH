set -euo pipefail

export PYTHONPATH="./src:${PYTHONPATH:-}"

DATASET="${DATASET:-Office}"
OUTPUT_DIR="${OUTPUT_DIR:-./ckpt/${DATASET}_DASH}"

python src/train.py --dataset "$DATASET" --output_dir "$OUTPUT_DIR" "$@"
python src/evaluate.py --dataset "$DATASET" --checkpoint "$OUTPUT_DIR"
